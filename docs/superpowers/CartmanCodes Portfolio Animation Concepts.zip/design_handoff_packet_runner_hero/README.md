# Handoff: InterviewVault Front Page — Hero + "Packet Runner" Mini-Game (concept 2a)

## Overview
A redesigned front-page hero for cartmancodes.com (InterviewVault). The existing hero copy (headline, subtitle, stats) moves to the **left column**; a playable snake-style mini-game called **Packet Runner** sits in the **right column** on a dark terminal-styled board. GitHub and LinkedIn links live in the top nav as icon buttons. Theme: "every doc travels as a packet" — the game lets visitors relax by routing packets while they browse.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy blindly.

- `packet-runner-hero.html` — a **standalone vanilla HTML/CSS/JS** reference of the final design. Since the target site is plain HTML/CSS/JS, this file is close to drop-in: open it in a browser, verify, then merge its markup/styles/script into the real front page (index.html), reusing the site's existing nav/footer where they already exist.
- `Front Page Animations.dc.html` — the original design-tool prototype (whole exploration canvas; concept `2a` is the relevant section). Reference only; it will not run outside the design tool.

## Fidelity
**High-fidelity.** Colors, typography, spacing and interactions are final intent. Recreate pixel-perfectly, matching the live site's existing values where they differ slightly (the prototype approximates the production palette).

## Screens / Views

### Hero section (single view)
**Purpose:** first screen of the site; communicates the value proposition and lets visitors play a 30-second game.

**Layout** (prototype canvas is 880×560; production should be fluid, max-width ~1100px, centered):
- **Top nav** — height 58px, flex row, `padding: 0 28px`, `gap: 24px`, bottom border `1px solid rgba(47,92,230,0.15)`, background `rgba(255,255,255,0.65)` over the page grid.
  - Logo: 26×26px square, `border-radius: 6px`, background `#2f5ce6`, white "IV" in JetBrains Mono 11px/700. Wordmark: 15px, "Interview" bold `#16233e` + "Vault" `#7e8aa6`.
  - Nav links: 12.5px, color `#44546e` (use the site's real nav).
  - **Right-aligned social icon buttons** (`margin-left: auto`, `gap: 10px`): 32×32px, `border: 1.5px solid rgba(47,92,230,0.45)`, `border-radius: 8px`, centered SVG brand mark filled `#2f5ce6` (GitHub 16px, LinkedIn 15px). Hover: `background: rgba(47,92,230,0.12); border-color: #2f5ce6`.
  - Links: GitHub → https://github.com/cartmancodes · LinkedIn → https://in.linkedin.com/in/shubhojeet-chakraborty-540570b0
- **Hero body** — flex row, `gap: 34px`, `padding: 34px 40px 0 48px`, `align-items: flex-start`.
  - **Left column** (`flex: 1; min-width: 0`):
    - Headline: 30px (scale up to ~44–54px on production full-width), `line-height: 1.12`, weight 800, `letter-spacing: -0.02em`, color `#16233e`; the phrase "designing systems" in accent `#2f5ce6`. Text: "Everything I know about designing systems, in one place."
    - Subtitle: serif (Source Serif 4 / Georgia), 14.5px (production ~17px), `line-height: 1.55`, color `#3d4c68`, `margin-top: 12px`. Text: "Worked breakdowns, pattern cheat-sheets and long-form notes — written to be read the week before an interview, and re-read the morning of."
    - Stats row: flex `gap: 26px`, `margin-top: 24px`. Each stat: number 20px/800 `#16233e`; label JetBrains Mono 9px, `letter-spacing: 1.6px`, uppercase, `#6b7a94`, `margin-top: 3px`. Values: 122 DOCUMENTS · 607 DIAGRAMS · 650k WORDS.
    - Terminal story lines: JetBrains Mono 11px, `#5c6b87`, `margin-top: 28px`, `line-height: 1.8`:
      - `$ ping knowledge.local`
      - `$ 64 bytes received: curiosity alive`
  - **Right column** (fixed width, `flex-shrink: 0`, contents centered):
    - Caption above board: JetBrains Mono 10.5px, `letter-spacing: 2.2px`, `#6b7a94`, uppercase: "PACKET RUNNER — DON'T DROP THE STREAM"
    - **Game board**: 400×240px, `margin-top: 12px`, background `#101b33`, `border-radius: 10px`, `overflow: hidden`, shadow `0 14px 34px rgba(16,27,51,0.35)`, faint cell grid via two linear-gradients `rgba(255,255,255,0.05) 1px` at `background-size: 20px 20px`.
    - Score row under board: flex `gap: 36px`, `margin-top: 16px`, JetBrains Mono — "PACKETS DELIVERED" 12px `#16233e` + score 18px/700 `#2f5ce6`; hint "← ↑ ↓ → OR WASD" 10.5px `#6b7a94`.

**Page background** (site-wide, already exists on the live site): `#eef3fa` with blueprint grid — two linear-gradients `rgba(47,92,230,0.07) 1px` at `background-size: 34px 34px`.

## Interactions & Behavior — Packet Runner game

**Grid:** 20 columns × 12 rows, 20px cells (board 400×240).

**Entities:**
- Snake segments: 18×18px, `border-radius: 4px`, positioned at `(x*20+1, y*20+1)`. Head `#63d68f`, body `#2f5ce6`.
- Packet (food): 11px circle `#63d68f`, glow `box-shadow: 0 0 10px rgba(99,214,143,0.8)`, opacity pulse animation (1 → 0.2 → 1, 1.2s ease-in-out infinite), centered in its cell. Spawns at a random free cell (never on the snake).

**Rules:**
- Initial snake: 3 segments at (9,6),(8,6),(7,6), moving right. Tick every **150ms** (setInterval).
- Controls: Arrow keys + WASD. Reversing direction is ignored. Only one direction change applied per tick (buffer the pending direction). `preventDefault()` on arrows **only while the game is running** so the page doesn't scroll.
- Eating a packet: +1 score, snake grows by one, new packet spawns.
- Hitting a wall or the snake's own body: game over.

**Overlay** (covers the board, `rgba(16,27,51,0.82)`, column-centered, `gap: 10px`):
- Idle: title "PACKET RUNNER" — sub "guide the stream · deliver packets · don't drop the connection" — button "START"
- Game over: title "CONNECTION DROPPED" — sub "connection dropped — N packets delivered" — button "RECONNECT"
- Title: JetBrains Mono 15px/700, `letter-spacing: 3px`, white. Sub: 10.5px `#9fb3dd`. Button: JetBrains Mono 12px/700, `letter-spacing: 2px`, white on `#2f5ce6`, `border-radius: 8px`, `padding: 10px 26px`; hover `#1e46c8`.

**Other animations:**
- Packet pulse: `@keyframes ping { 0%,100% {opacity:1} 50% {opacity:0.2} }`, 1.2s ease-in-out infinite.
- Icon-button hovers as above. No other motion in this concept.
- Respect `prefers-reduced-motion`: disable the pulse; the game itself only runs on explicit START.

## State Management
- `snake: {x,y}[]`, `dir` / `pendingDir: {x,y}`, `food: {x,y}`
- `score: number`, `running: boolean`, `gameOver: boolean`
- Timer handle for the 150ms tick; keydown listener added once, removed on teardown. No data fetching.

## Design Tokens
- Accent blue: `#2f5ce6` (hover dark: `#1e46c8`)
- Ink / navy: `#16233e` · Terminal board: `#101b33`
- Body text: `#3d4c68` · Muted: `#5c6b87` · Label gray-blue: `#6b7a94` · Terminal text: `#9fb3dd`
- Packet green: `#63d68f` · Page bg: `#eef3fa` · Grid line: `rgba(47,92,230,0.07)`
- Fonts: system sans (headings/UI), Source Serif 4 (subtitle), JetBrains Mono (labels, game UI) — Google Fonts: `JetBrains+Mono:wght@400;500;700`, `Source+Serif+4`
- Radii: 6px (logo), 8px (buttons), 10px (board) · Board shadow: `0 14px 34px rgba(16,27,51,0.35)`

## Assets
- GitHub and LinkedIn brand-mark SVG paths are inlined in the HTML (standard simple marks, no external files).
- No images required.

## Files
- `packet-runner-hero.html` — standalone vanilla reference (open directly in a browser)
- `Front Page Animations.dc.html` — original prototype canvas (concept `2a` = the section at the top)
