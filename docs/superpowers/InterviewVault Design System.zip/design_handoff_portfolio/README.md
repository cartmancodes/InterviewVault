# Handoff: Personal Portfolio — Shubhojeet Chakraborty (cartmancodes)

## Overview
A single-page personal portfolio for Shubhojeet Chakraborty (github.com/cartmancodes), Technical Lead, AI/ML at Arcesium. Audience: senior engineers, hiring managers, staff+ interviewers deciding in ~90 seconds whether he's worth a conversation. Sections: hero (mountain scene + polaroid), Experience (with a career-as-system-diagram), Projects, Notes (funnels to his InterviewVault site at cartmancodes.com), Hobbies, footer.

Theme: **"construction paper"** — a South Park-inspired flat-cutout look (bright sky, snow-capped peaks, pine trees, thick ink outlines, hard offset shadows) built on top of his InterviewVault engineering-blueprint identity (IBM Plex type, ink #0E1A2B discipline).

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, NOT production code to copy directly. Recreate these designs in the target codebase's environment (React, Astro, plain static HTML — whatever the site uses) with its established patterns. If no environment exists yet, a static single-page site (plain HTML/CSS or Astro) is the right weight; there is no app logic beyond hover states and one entry animation.

- `portfolio-reference.html` — **the design, self-contained.** Open in a browser. All styles are inline; fonts load from Google Fonts. This is the source of truth for every measurement, color, and string of copy.
- `Portfolio.dc.html.txt` — the original design-component source (same markup, plus the theming hooks described under Design Tokens).
- `assets/cartman.png` — the hero polaroid image (user-supplied).
- `assets/logo.svg` — the "IV" InterviewVault mark (referenced for context; portfolio draws its IV badge inline).
- `interviewvault-tokens.css` — the parent design system's tokens (base identity the theme grew from).
- `resume.pdf` — content ground truth for experience entries.

## Fidelity
**High-fidelity.** Recreate pixel-perfectly: exact hex values, font sizes, paddings, border widths, and shadow offsets as in `portfolio-reference.html`. Copy text verbatim from the reference file.

## Fonts
Google Fonts, three IBM Plex voices with fixed jobs:
- IBM Plex Sans 400/500/600/700 — UI chrome, headings
- IBM Plex Serif 400/600 — long-form prose (hobby paragraphs)
- IBM Plex Mono 400/500/600/700 — labels, pills, meta, dates, wordmark
Import: `https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Serif:wght@400;600&display=swap`

## Design Tokens
Theme values (used throughout; exact usage in the reference file):
- Ink (text, borders, shadows): `#0E1A2B`
- Sky (hero + footer background): `#79C3F0`
- Accent `--acc` (default pom yellow): `#FFD808` — alternates offered as a theme toggle: teal `#4FC3D9`, red `#E23D3D`. Accent colors: hero badge bg, founding-engineer pills, highlighted diagram node, Notes banner bg, all hover fills.
- Mountains: `#8C97AB` (near), `#A6B0C2` (far); snow caps `#FFFFFF`; pines `#2E7D46`, `#3C9159`; snow ground `#FFFFFF`
- Secondary text: `#3A4A61`; muted mono: `#6B7C96`; prose: `#16233A`; hairline rules: `#E4EAF5`
- Borders: `2px solid #0E1A2B` on every card/pill/button ("paper cutout" outline); timeline rows use 1px `#E4EAF5`
- Shadows: hard offset, no blur — cards `4px 4px 0 #0E1A2B`, hover `6px 6px 0 #0E1A2B`, polaroid `5px 5px 0 #0E1A2B`
- Radii: cards 10px, polaroid 6px (inner img 4px), pills/nav/buttons 100px, diagram nodes rx=8
- Section label: inline pill — mono 600 13px, letter-spacing .1em, uppercase, `#0E1A2B` bg, white text, padding 6px 14px
- Content shell: max-width 1180px, side padding 32px

## Screens / Views (single page)

### 1. Hero (sky scene)
- Background `#79C3F0`; an SVG landscape pinned to the bottom (300px tall, `preserveAspectRatio="none"`): three snow-capped triangle mountains, a 48px white snow band, four pine triangles. Exact polygon points in the reference SVG.
- Top nav row: mono 700 16px white wordmark "cartmancodes" with `text-shadow: 2px 2px 0 #0E1A2B` (left), then pill links Experience / Projects / Notes / Hobbies — white bg, 2px ink border, mono 600 12px uppercase; hover fills accent.
- Left column (flex 1 1 460px): yellow badge pill "SHUBHOJEET CHAKRABORTY · TECHNICAL LEAD, AI/ML · ARCESIUM"; H1 700, `clamp(32px, 4.6vw, 46px)`, line-height 1.05, white with `text-shadow: 3px 3px 0 #0E1A2B`: "Building systems at scale by day. Crafting ambitious side projects by night."; three 38px icon buttons (GitHub, LinkedIn, mailto) — white bg, 2px ink border, radius 10, hover accent. Icon SVGs are inlined in the reference.
- Right column (flex 0 1 400px): polaroid card rotated −2°, white bg, 2px ink border, shadow 5px 5px 0; `assets/cartman.png` inside with its own 2px ink border; mono caption `STAFF PHOTO — "I'M NOT LAZY, I'M ASYNC."`
- Links: GitHub https://github.com/cartmancodes · LinkedIn https://in.linkedin.com/in/shubhojeet-chakraborty-540570b0 · mailto:shubhchak@gmail.com

### 2. Experience
- "Experience" section pill, then the **career system diagram** (SVG, viewBox 0 0 1000 150, hidden below 680px viewport):
  - 5 nodes left→right: Samsung · Advanced Software (2017–19), Arcesium · Regulatory ETL (2019–21), Arcesium · ARMOR (2021–23), Arcesium · TRACS (2023–25), Arcesium Intelligence (2025—, accent fill; check the source for the user-tuned rect width). White fill (last node accent), 2px ink stroke, rx 8; label Sans 600 11–12px, year Mono 11 `#6B7C96`.
  - Ink 2px arrows between nodes, drawn-in via stroke-dashoffset animation (.9s ease, staggered +.12s); dashed bracket line above nodes 2–4 labeled "regulated scale"; mono captions under each node (OpenGL ES · 60fps / MiFID · EMIR / TICB · TIC SLT / MiFID · MAS / LiteLLM · Claude Agent SDK).
- Timeline grid `clamp(84px,12vw,140px) 1fr`; date col mono 11.5 `#6B7C96`; each entry: title Sans 600 15.5px + (where applicable) "founding engineer" pill (accent bg, 2px ink border, mono 600 10.5px); body 14px `#3A4A61`, max-width 66ch; rows divided by 1px `#E4EAF5`. Five entries — copy verbatim from the reference (Arcesium Intelligence entry covers the LiteLLM proxy gateway and Claude Agent SDK in sandboxed environments on AWS Lambda / PostgreSQL / S3 / EKS + Fargate).
- Stack pill row (white pills, 2px ink border, mono 600 11px): Java/Spring Boot, Python/FastAPI, Spark, LiteLLM, LangGraph, C++, Postgres + pgvector, Redis, AWS EKS, Azure VMSS, Argo Workflows, React/TypeScript.
- Creds line, mono 11.5 `#6B7C96`: "ACM ICPC regionals 2017 · national rank 57 in prelims — Codeforces Expert (1775) — Codechef 5★".

### 3. Projects
Grid `repeat(auto-fit, minmax(240px, 1fr))`, gap 14. Two cards (litellm-rust, kafka-poc): white, 2px ink border, radius 10, shadow 4px→6px on hover; title 600 15px, body 12.5px `#3A4A61`, meta mono 10.5 `#6B7C96`. Real GitHub links.

### 4. Notes (InterviewVault funnel)
Accent-bg banner card (2px ink border, radius 10, offset shadow, hover 6px): 42px ink "IV" square badge, title "The notes section is a whole website — InterviewVault", sub "122 worked system-design documents · 615 diagrams · 5 CI gates · a practice layer with XP · a snake game. Enter the vault →", right-aligned mono "cartmancodes.com ↗". Links to https://cartmancodes.com. Below: three white pill links — dsa track → (https://cartmancodes.com/#dsa), deep dives → (https://cartmancodes.com/#deep-dives), play packet runner → (https://cartmancodes.com).

### 5. Hobbies
Two cards (grid auto-fit minmax(280px,1fr)): Music theory, Football. Title Sans 600 15px; body IBM Plex Serif 14.5/1.7 `#16233A`. Copy verbatim from reference.

### 6. Footer
Sky `#79C3F0`, 2px ink top border; mono 600 12px ink; left: name + mailto + github + linkedin links (ink-colored); right: `$ exit 0`.

## Interactions & Behavior
- Hover: nav pills / social buttons / white pill links fill `--acc`; cards grow shadow 4px 4px 0 → 6px 6px 0 (no transform).
- Entry animation: diagram arrows draw in once on load (`stroke-dasharray/-offset` + `@keyframes draw`, .9s ease, staggered).
- `prefers-reduced-motion: reduce` → kill all animation durations/delays.
- Responsive: hero columns and pill rows flex-wrap; timeline date column clamps to 84px; diagram hidden ≤680px (timeline carries the story); page must work to 320px.
- Keyboard focus: give links/buttons a visible focus ring (parent system uses `outline: 2px solid #2563EB; outline-offset: 2px`).
- Nav pills anchor-scroll to #experience / #projects / #notes / #hobbies.

## State Management
None required. Optional theme toggle: single CSS custom property `--acc` (#FFD808 / #4FC3D9 / #E23D3D) — every accent usage reads `var(--acc, #FFD808)`.

## Assets
- `assets/cartman.png` — user-supplied South Park character image (728×563 PNG, no alpha). **Licensing is the owner's responsibility** — the character is Paramount IP; it was supplied by the site owner, not drawn for this design.
- `assets/logo.svg` — InterviewVault "IV" mark (blue #2563EB rounded square, mono IV). The portfolio's IV badge is drawn inline with ink bg instead.
- GitHub/LinkedIn glyphs: inline SVG paths in the reference (copied from the production InterviewVault site); mail glyph is a 2px-stroke envelope.
- Mountains/pines: inline SVG polygons — part of the design, not external assets.

## Files
- `portfolio-reference.html` — open-in-browser design reference (source of truth)
- `Portfolio.dc.html.txt` — original component source with theming hooks
- `interviewvault-tokens.css` — parent design-system tokens
- `assets/` — cartman.png, logo.svg
- `resume.pdf` — experience content ground truth
